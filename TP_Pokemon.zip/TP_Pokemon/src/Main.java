public class Main {
    public static void main(String[] args) {
        Pokemon pikachu = new Pokemon(25, "Pikachu", "Électrique", 50, 120, 55, 40, 50, 50, 90);
        Pokemon charizard = new Pokemon(6, "Charizard", "Feu", 50, 150, 84, 78, 109, 85, 100);

        System.out.println(pikachu);
        System.out.println(charizard);

        System.out.println("Pikachu attaque Charizard!");
        int dommages = pikachu.calculerDommage(charizard, 50); // assuming 50 is the power of the attack
        System.out.println("Dommages causés: " + dommages);

        if (pikachu.estPremierAttaque(charizard)) {
            System.out.println("Pikachu attaque en premier!");
        } else {
            System.out.println("Charizard attaque en premier!");
        }
    }
}
